package com.wahyurhy.bento_umeezo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
