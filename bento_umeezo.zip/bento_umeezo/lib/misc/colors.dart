import 'dart:ui';

class AppColors {
  static final Color bottonColorBrown = Color(0xFF9F4614);
  static final Color cardColorDarkGrey = Color(0xFF2F2F2F);
}